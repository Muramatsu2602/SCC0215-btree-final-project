# SCC0215 - Project 1

Este trabalho tem como objetivo armazenar dados em um arquivo binário de acordo com uma organização de campos e registros, bem como recuperar todos os dados armazenados.

## Project Structure
```.
├── binary
│   └── ...
├── csv
├── LICENSE
├── main.c
├── Makefile
├── README.md
├── register
│   └── ...
└── utils
    └── ...
```

## Presentation Video 

## Team
* 1179444 - Giovanni Shibaki Camargo
* 11796451 - Pedro Kenzo Muramatsu Carmo

## Acknowledgements
